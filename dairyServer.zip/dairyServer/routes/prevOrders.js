const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const {authModel,dairyproduct,previousOrders,adminUserView,mongoose} = require("../models/dbSchema");
const secretkey = "djahdfah@45ljs893ljf#e68f";
const verifyToken = require('../verifyToken')
const mongodb=require('mongodb')


router.get('',async(req,res)=>{

    try{
      let userData=await previousOrders.find()
      if(userData)
      res.send(userData)
      else
      res.send({statusCode:400,Message:"Invalid ID"})
     
    }catch(error){
      console.log(error)
      res.send({statusCode:500,message:"Internal Server Error",error})
    }
  
  })

  router.post('',async(req,res)=>{
    try{
      let resolve=await previousOrders.create(req.body)
      res.send(resolve)
    }catch(error){
      console.log(error)
      res.send({statusCode:500,message:"Internal Server Error",error})
    }
  })
//get individual users previous orders by ID
  router.get('/:id',async(req,res)=>{

    try{
      let userData=await previousOrders.findOne({userId:req.params.id})
      if(userData)
      res.send(userData)
      else
      res.send({statusCode:400,Message:"Invalid ID"})
     
    }catch(error){
      console.log(error)
      res.send({statusCode:500,message:"Internal Server Error",error})
    }
  
  })
  router.put('/:id',async(req,res)=>{
    try{
      let lead=await previousOrders.updateOne({userId:req.params.id},{$set:req.body},{runValidators:true})
      res.send({statusCode:200,
        message:"Request Saved:Updated"})
    }catch(error){
      console.log(error)
      res.send({
        statusCode:500,
        message:"Internal Server Error",
        error})
    }
  
  })
module.exports = router;