const express = require("express");
const router = express.Router();
const {authModel,dairyproduct,previousOrders,adminUserView,mongoose} = require("../models/dbSchema");
const mongodb=require('mongodb')





router.get('/customers',async(req,res)=>{

    try{
      let userData=await adminUserView.find()
      if(userData)
      res.send(userData)
      else
      res.send({statusCode:400,Message:"Invalid ID"})
     
    }catch(error){
      console.log(error)
      res.send({statusCode:500,message:"Internal Server Error",error})
    }
  
  })
  router.get('/customers/:id',async(req,res)=>{

    try{
      let lead=await adminUserView.findOne({_id:mongodb.ObjectId(req.params.id)})
      if(lead)
      res.send(lead)
      else
      res.send({statusCode:400,Message:"Invalid ID"})
     
    }catch(error){
      console.log(error)
      res.send({statusCode:500,message:"Internal Server Error",error})
    }
  
  })
  router.get('/cust/:id',async(req,res)=>{

    try{
      let userData=await adminUserView.find({userId:req.params.id})
      if(userData)
      res.send(userData)
      else
      res.send({statusCode:400,Message:"Invalid ID"})
     
    }catch(error){
      console.log(error)
      res.send({statusCode:500,message:"Internal Server Error",error})
    }
  
  })
  
  router.post('/customers',async(req,res)=>{
    try{
      let resolve=await adminUserView.create(req.body)
      res.send({statusCode:200,message:"Request Saved"})
    }catch(error){
      console.log(error)
      res.send({statusCode:500,message:"Internal Server Error",error})
    }
  })


 
module.exports = router;