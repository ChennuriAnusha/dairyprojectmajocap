const express = require("express");
const router = express.Router();
const { authModel,dairyproduct, mongoose } = require("../models/dbSchema");
const mongodb=require('mongodb')


router.get('/:id',async(req,res)=>{

    try{
      let userData=await authModel.findOne({_id:mongodb.ObjectId(req.params.id)})
      if(userData)
      res.send(userData)
      else
      res.send({statusCode:400,Message:"Invalid ID"})
     
    }catch(error){
      console.log(error)
      res.send({statusCode:500,message:"Internal Server Error",error})
    }
  
  })


  router.get('',async(req,res)=>{

    try{
      let userData=await authModel.find()
      if(userData)
      res.send(userData)
      else
      res.send({statusCode:400,Message:"Invalid ID"})
     
    }catch(error){
      console.log(error)
      res.send({statusCode:500,message:"Internal Server Error",error})
    }
  
  })

  router.put('/:id',async(req,res)=>{
    try{
      let lead=await authModel.updateOne({_id:mongodb.ObjectId(req.params.id)},{$set:req.body},{runValidators:true})
      res.send({statusCode:200,
        message:"Request Saved:Updated"})
    }catch(error){
      console.log(error)
      res.send({
        statusCode:500,
        message:"Internal Server Error",
        error})
    }
  
  })


module.exports = router;