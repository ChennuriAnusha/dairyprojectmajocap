const express = require('express')
const app = express()
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const dbName='anusha';
const dbUrl=`mongodb+srv://anusha:Anu123@cluster0.ovblshr.mongodb.net/${dbName}`

const authRouter = require('./routes/auth')
const productRouter=require('./routes/product')
const userRouter=require('./routes/userdata')
const adminRouter=require('./routes/admin')
const prevOrdersRouter=require('./routes/prevOrders')

const cors = require('cors')
//middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({extended: true}))

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  
  });


mongoose.connect(dbUrl,{

    tlsAllowInvalidHostnames: true,
  
    tlsAllowInvalidCertificates: true,
  
})

mongoose.connection.on('open', ()=>{
    console.log('database connected')
})
 
app.listen(3000, (err)=>{
    if(!err){
        console.log("app is running on 3000")
    }
})
app.use('/auth',authRouter)
app.use('/product',productRouter)
app.use('/userdata',userRouter)
app.use('/admin',adminRouter)
app.use('/prevOrders',prevOrdersRouter)
module.exports = app;
