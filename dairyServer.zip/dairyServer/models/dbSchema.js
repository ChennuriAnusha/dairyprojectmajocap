const mongoose = require('mongoose')

const authModelSchema = new mongoose.Schema({
    username:{type:String,required:true},
    email:{type:String,required:true},
    password:{type:String,required:true},
    current_cart:[{
      _id:{type:String,required:true},
      product_name: {type:String,required:true},
      product_Image: {type:String,required:true},
      price: {type:Number,required:true},
      vendor_Name: {type:String,required:true},
      vendor_Contact: {type:String,required:true},
      Quantity:{type:Number,default:1}
    }]
})

const milkcurdSchema = new mongoose.Schema({
   product_name: {type:String,required:true},
  product_Image: {type:String,required:true},
  price: {type:Number,required:true},
  vendor_Name: {type:String,required:true},
  vendor_Contact: {type:String,required:true},
})
const adminUserDataSchema=new mongoose.Schema({
  userId:{type:String,required:true},
  username:{type:String,required:true},
  phoneNumber:{type:Number,required:true},
  Address:{type:String,required:true},

  current_cart:[{
    _id:{type:String,required:true},
    product_name: {type:String,required:true},
    product_Image: {type:String,required:true},
    price: {type:Number,required:true},
    vendor_Name: {type:String,required:true},
    vendor_Contact: {type:String,required:true},
    Quantity:{type:Number,default:1}
  }],
  total_bill:{type:Number,required:true},
  dateOfOrder:{type:Number,default:Date.now()}
})


const previousOrdersSchema=new mongoose.Schema({
  userId:{type:String,required:true},
  previous_cart:[{
    order_id:{type:String,required:true},
    orders:[{
      prev_orders:[{
      product_name: {type:String,required:true},
      product_Image: {type:String,required:true},
      price: {type:Number,required:true},
      vendor_Name: {type:String,required:true},
      vendor_Contact: {type:String,required:true},
      Quantity:{type:Number,default:1}
      }],
      total_bill:{type:Number,required:true},
      dateOfOrder:{type:Number,default:Date.now()}
    }]
  }],
  
})






const authModel  = mongoose.model('authUsers',authModelSchema)
const dairyproduct=mongoose.model('dairyproducts',milkcurdSchema)
const previousOrders=mongoose.model('previousOrders',previousOrdersSchema)
const adminUserView=mongoose.model('adminUserView',adminUserDataSchema)

module.exports = {authModel,dairyproduct,previousOrders,adminUserView,mongoose}
